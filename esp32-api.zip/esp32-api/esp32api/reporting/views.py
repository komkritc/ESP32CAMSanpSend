from django.shortcuts import render
from django.http import JsonResponse
from .forms import UploadImageForm

def upload_image(request):
    if request.method == 'POST':
        form = UploadImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return JsonResponse({'message': 'File uploaded successfully!'})
        else:
            return JsonResponse({'error': 'Invalid form submission'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)
